#!/usr/bin/env python
# coding:utf-8
# autoGHost - A Simple hosts file maintainer
# Contributor:
#      Sheep Sheep    <sora8964@gmail.com>

__version__ = '0.1'

import os
import sys
import glob



sys.path += glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'python*.zip'))

import re
import ssl
import sys
import socket
import dns.resolver
from urlparse import urlparse

# Options
lhosts="C:\Windows\System32\drivers\etc\hosts"
rhosts="http://smartladder.googlecode.com/svn/hosts/pc/hosts"

startmarker="\r\n# autoGHost MARKER: START\r\n"
sourcemarker="# autoGHost SOURCE: %s\r\n" % rhosts
endmarker="\r\n# Powered By AutoGHost \r\n"

# 
opclear=False
for arg in sys.argv: 
    if(arg == "--clean"):
		opclear=True

# DNSQuery
gaddrs=[]
gquery=dns.resolver.query('www.google.com', 'A')

for answer in gquery:
    gaddrs.append(str(answer))

# Socket
rhosts=urlparse(rhosts)

for gaddr in gaddrs:
	print "Trying %s" % gaddr,
	s = socket.socket()
	if(rhosts.scheme == "https"):
		rport=443
		sock=ssl.wrap_socket(s)
	else:
		rport=80
		sock=s
	
	try:
		sock.connect((gaddr, rport))
	except Exception, e:
		print "Walled!"
		continue
	
	try:
		sock.send("GET %s HTTP/1.0\r\nHost: %s\r\n\r\n" % (rhosts.path, rhosts.netloc))
	except Exception, e:
		print "Walled!"
		continue

	data=""
	while 1:
		buffer = sock.recv(1024)
		if not buffer: break
		data+=buffer
		
	length=len(data)/1024
	if(not len):
		print "Walled!"
		continue
	else:
		print "OK! (%gK)" % length
		break
	
data="%s%s%s%s" % (startmarker, sourcemarker, data[data.index("\r\n\r\n"):len(data)], endmarker)

if os.path.isfile(lhosts):
	with open(lhosts, 'rb') as fp:
		content = fp.read()
else:
	content=""

if(startmarker in content and endmarker in content):
	if(opclear == True):
		data=""
	content="%s%s%s" % (content[0:content.index(startmarker)], data, content[content.index(endmarker)+len(endmarker):len(content)])
elif opclear == False:
	content="%s%s" % (content, data)

with open(lhosts, 'wb') as fp:
	fp.write(content)